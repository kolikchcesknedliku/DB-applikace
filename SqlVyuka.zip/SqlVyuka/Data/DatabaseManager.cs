using Microsoft.Data.Sqlite;
using System.Data;

namespace SqlVyuka.Data;

public class DatabaseManager : IDisposable
{
    private readonly SqliteConnection _connection;
    public string DbPath { get; }

    public DatabaseManager(string dbPath)
    {
        DbPath = dbPath;
        _connection = new SqliteConnection($"Data Source={dbPath}");
        _connection.Open();
        InitializeDatabase();
    }

    private void InitializeDatabase()
    {
        // Vytvoření tabulek
        ExecuteNonQuery(@"
            CREATE TABLE IF NOT EXISTS studenti (
                id       INTEGER PRIMARY KEY AUTOINCREMENT,
                jmeno    TEXT    NOT NULL,
                prijmeni TEXT    NOT NULL,
                vek      INTEGER NOT NULL,
                mesto    TEXT    NOT NULL,
                email    TEXT    NOT NULL UNIQUE
            );

            CREATE TABLE IF NOT EXISTS kurzy (
                id      INTEGER PRIMARY KEY AUTOINCREMENT,
                nazev   TEXT    NOT NULL,
                kredity INTEGER NOT NULL,
                lektor  TEXT    NOT NULL
            );

            CREATE TABLE IF NOT EXISTS zapsani (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                student_id INTEGER NOT NULL REFERENCES studenti(id) ON DELETE CASCADE,
                kurz_id    INTEGER NOT NULL REFERENCES kurzy(id)    ON DELETE CASCADE,
                znamka     TEXT    NOT NULL
            );
        ");

        // Naplnění ukázkovými daty (jen pokud je tabulka prázdná)
        var count = ExecuteScalar("SELECT COUNT(*) FROM studenti");
        if (Convert.ToInt64(count) > 0) return;

        ExecuteNonQuery(@"
            INSERT INTO studenti (jmeno, prijmeni, vek, mesto, email) VALUES
                ('Jan',   'Novák',      23, 'Praha',   'jan.novak@skola.cz'),
                ('Marie', 'Svobodová',  21, 'Brno',    'marie.svobodova@skola.cz'),
                ('Petr',  'Dvořák',     25, 'Praha',   'petr.dvorak@skola.cz'),
                ('Anna',  'Horáková',   22, 'Plzeň',   'anna.horakova@skola.cz'),
                ('Tomáš', 'Procházka',  24, 'Ostrava', 'tomas.prochazka@skola.cz'),
                ('Lucie', 'Krejčí',     20, 'Praha',   'lucie.krejci@skola.cz');

            INSERT INTO kurzy (nazev, kredity, lektor) VALUES
                ('Databáze a SQL',       6, 'Ing. Novotný'),
                ('Algoritmizace',        5, 'doc. Černý'),
                ('Webové technologie',   4, 'Mgr. Marková'),
                ('Počítačové sítě',      6, 'Ing. Blažek'),
                ('Operační systémy',     4, 'doc. Šimánek');

            INSERT INTO zapsani (student_id, kurz_id, znamka) VALUES
                (1,1,'A'),(1,2,'B'),(1,3,'A'),
                (2,1,'B'),(2,4,'A'),
                (3,2,'C'),(3,5,'B'),
                (4,1,'A'),(4,3,'B'),
                (5,4,'C'),
                (6,2,'A'),(6,3,'A');
        ");
    }

    // ── Spuštění SELECT dotazu → vrátí DataTable ──────────────────────────
    public DataTable ExecuteQuery(string sql)
    {
        var dt  = new DataTable();
        var cmd = _connection.CreateCommand();
        cmd.CommandText = sql;
        using var reader = cmd.ExecuteReader();
        dt.Load(reader);
        return dt;
    }

    // ── Spuštění INSERT / UPDATE / DELETE → počet ovlivněných řádků ───────
    public int ExecuteNonQuery(string sql)
    {
        var cmd = _connection.CreateCommand();
        cmd.CommandText = sql;
        return cmd.ExecuteNonQuery();
    }

    // ── Spuštění skalárního dotazu ────────────────────────────────────────
    public object? ExecuteScalar(string sql)
    {
        var cmd = _connection.CreateCommand();
        cmd.CommandText = sql;
        return cmd.ExecuteScalar();
    }

    // ── Seznam tabulek v databázi ─────────────────────────────────────────
    public List<string> GetTableNames()
    {
        var names = new List<string>();
        var dt = ExecuteQuery("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name;");
        foreach (DataRow row in dt.Rows)
            names.Add(row[0]?.ToString() ?? "");
        return names;
    }

    public void Dispose()
    {
        _connection.Close();
        _connection.Dispose();
    }
}
