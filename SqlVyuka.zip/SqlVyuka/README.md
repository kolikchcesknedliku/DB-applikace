# SQL Výukový program – C# WinForms + SQLite

## Požadavky
- **Visual Studio 2022** (Community nebo vyšší) s pracovní zátěží **.NET Desktop Development**
- **.NET 6** nebo novější (součástí VS 2022)
- Internet při prvním sestavení (NuGet stáhne balíček `Microsoft.Data.Sqlite`)

## Jak spustit

1. Otevřete Visual Studio 2022
2. Zvolte **File → Open → Project/Solution**
3. Vyberte soubor `SqlVyuka.csproj`
4. Stiskněte **F5** (nebo tlačítko ▶ Start)

Visual Studio automaticky stáhne NuGet balíčky a sestaví projekt.

## Struktura projektu

```
SqlVyuka/
├── SqlVyuka.csproj          ← definice projektu (.NET 6 WinForms)
├── Program.cs               ← vstupní bod aplikace
├── Data/
│   └── DatabaseManager.cs  ← veškerá práce s SQLite (CRUD, schema)
└── Forms/
    └── MainForm.cs          ← hlavní okno aplikace (UI + logika)
```

## Funkce aplikace

### SQL Editor (záložka)
- Vlastní SQL dotazy s barevným editorem (tmavý styl)
- Spuštění přes **F5** nebo **Ctrl+Enter**
- Výsledky v tabulce DataGridView
- **9 přednastavených dotazů** (SELECT, WHERE, JOIN, GROUP BY, INSERT, UPDATE, DELETE…)

### Správa studentů (záložka)
- Zobrazení všech studentů
- Přidání, úprava, smazání přes formulář
- Kliknutím na řádek se data načtou do formuláře

### Správa kurzů (záložka)
- Stejný CRUD jako u studentů

### Zápisy (záložka)
- JOIN pohled: student ↔ kurz ↔ známka
- Přidání/odebrání zápisu přes combobox

### Schéma databáze (levý panel)
- Strom tabulek a sloupců
- Dvojklik na tabulku → SELECT * do editoru

## Databáze
Soubor `vyuka.db` se uloží do:
```
C:\Users\<uživatel>\AppData\Roaming\SqlVyuka\vyuka.db
```
Lze otevřít jinou databázi přes **Soubor → Otevřít databázi…**

## Tabulky

| Tabulka   | Sloupce                                  |
|-----------|------------------------------------------|
| studenti  | id, jmeno, prijmeni, vek, mesto, email   |
| kurzy     | id, nazev, kredity, lektor               |
| zapsani   | id, student_id (FK), kurz_id (FK), znamka|

## Příklady dotazů

```sql
-- Základní výběr
SELECT * FROM studenti;

-- Filtrování
SELECT jmeno, prijmeni FROM studenti WHERE mesto = 'Praha';

-- JOIN
SELECT s.jmeno, s.prijmeni, k.nazev, z.znamka
FROM studenti s
JOIN zapsani z ON s.id = z.student_id
JOIN kurzy k ON k.id = z.kurz_id;

-- Agregace
SELECT mesto, COUNT(*) AS pocet, AVG(vek) AS prumer
FROM studenti
GROUP BY mesto;
```
