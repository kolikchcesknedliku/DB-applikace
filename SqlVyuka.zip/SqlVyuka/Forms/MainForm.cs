using SqlVyuka.Data;
using System.Data;

namespace SqlVyuka.Forms;

public class MainForm : Form
{
    private DatabaseManager _db = null!;
    private TextBox         txtSQL    = null!;
    private DataGridView    dgvResult = null!;
    private Label           lblStatus = null!;
    private ListBox         lstTables = null!;

    // ukazkove dotazy (index 0 = prvni polozka v comboboxu)
    private readonly string[] Dotazy =
    {
        "SELECT * FROM studenti;",
        "SELECT * FROM kurzy;",
        "SELECT * FROM zapsani;",
        "SELECT jmeno, prijmeni FROM studenti WHERE mesto = 'Praha';",
        "SELECT jmeno, prijmeni, vek FROM studenti ORDER BY prijmeni;",
        "SELECT COUNT(*) AS pocet, AVG(vek) AS prumer FROM studenti;",
        "SELECT s.jmeno, s.prijmeni, k.nazev, z.znamka\nFROM studenti s\nJOIN zapsani z ON s.id = z.student_id\nJOIN kurzy k ON k.id = z.kurz_id;",
        "INSERT INTO studenti (jmeno, prijmeni, vek, mesto, email)\nVALUES ('Jan', 'Testovaci', 20, 'Brno', 'test@skola.cz');",
        "UPDATE studenti SET vek = 25 WHERE email = 'test@skola.cz';",
        "DELETE FROM studenti WHERE email = 'test@skola.cz';",
    };

    public MainForm()
    {
        Text          = "SQL Vyukovy program";
        Size          = new Size(960, 620);
        StartPosition = FormStartPosition.CenterScreen;
        Font          = new Font("Segoe UI", 9.5f);

        // levy panel - seznam tabulek v databazi
        var pnlLeft = new Panel { Width = 180, Dock = DockStyle.Left };

        var lblTables = new Label
        {
            Text      = "Tabulky (dvojklik = SELECT)",
            Dock      = DockStyle.Top,
            Height    = 40,
            TextAlign = ContentAlignment.MiddleCenter,
            BackColor = Color.SteelBlue,
            ForeColor = Color.White,
            Font      = new Font("Segoe UI", 9f, FontStyle.Bold),
        };

        lstTables = new ListBox { Dock = DockStyle.Fill, BorderStyle = BorderStyle.None };
        lstTables.MouseDoubleClick += (s, e) =>
        {
            if (lstTables.SelectedItem is string tbl)
            {
                txtSQL.Text = $"SELECT * FROM {tbl};";
                SpustDotaz();
            }
        };

        pnlLeft.Controls.Add(lstTables);
        pnlLeft.Controls.Add(lblTables);

        // pravy panel - SQL editor a vysledky
        var pnlRight = new Panel { Dock = DockStyle.Fill, Padding = new Padding(8) };

        var lblPriklady = new Label { Text = "Priklady:", AutoSize = true, Top = 8, Left = 0 };
        var cmbDotazy   = new ComboBox
        {
            DropDownStyle = ComboBoxStyle.DropDownList,
            Top = 4, Left = 70, Width = 550,
        };
        cmbDotazy.Items.Add("-- vyber ukazkovy dotaz --");
        foreach (var d in Dotazy)
            cmbDotazy.Items.Add(d.Split('\n')[0]); // zobraz jen prvni radek dotazu
        cmbDotazy.SelectedIndex = 0;
        cmbDotazy.SelectedIndexChanged += (s, e) =>
        {
            int i = cmbDotazy.SelectedIndex - 1; // -1 kvuli placeholder polozce
            if (i >= 0) txtSQL.Text = Dotazy[i];
        };

        txtSQL = new TextBox
        {
            Multiline     = true,
            ScrollBars    = ScrollBars.Vertical,
            Font          = new Font("Consolas", 10.5f),
            Top           = 34, Left = 0, Height = 130,
            AcceptsReturn = true,
            Text          = "SELECT * FROM studenti;",
        };

        var btnSpustit = new Button
        {
            Text      = "▶  Spustit  (F5)",
            Top       = 172, Left = 0, Width = 150, Height = 30,
            BackColor = Color.SteelBlue,
            ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat,
            Font      = new Font("Segoe UI", 9.5f, FontStyle.Bold),
        };
        btnSpustit.FlatAppearance.BorderSize = 0;
        btnSpustit.Click += (s, e) => SpustDotaz();

        var btnVymazat = new Button
        {
            Text = "Vymazat", Top = 172, Left = 158, Width = 90, Height = 30,
            FlatStyle = FlatStyle.Flat,
        };
        btnVymazat.Click += (s, e) => txtSQL.Clear();

        lblStatus = new Label
        {
            Text = "Pripraveno.", Top = 210, Left = 0,
            AutoSize = true, ForeColor = Color.DimGray,
        };

        dgvResult = new DataGridView
        {
            Top = 234, Left = 0,
            ReadOnly              = true,
            AllowUserToAddRows    = false,
            AllowUserToDeleteRows = false,
            AutoSizeColumnsMode   = DataGridViewAutoSizeColumnsMode.AllCells,
            SelectionMode         = DataGridViewSelectionMode.FullRowSelect,
            BackgroundColor       = Color.White,
            BorderStyle           = BorderStyle.None,
        };

        pnlRight.Controls.AddRange(new Control[]
            { lblPriklady, cmbDotazy, txtSQL, btnSpustit, btnVymazat, lblStatus, dgvResult });

        Controls.Add(pnlRight);
        Controls.Add(pnlLeft);

        // F5 spusti dotaz odkudkoliv v okne
        KeyPreview = true;
        KeyDown   += (s, e) => { if (e.KeyCode == Keys.F5) SpustDotaz(); };

        Resize += (s, e) => UpravRozvrzeni();
        Shown  += (s, e) =>
        {
            OtevriDatabazi();
            NactiTabulky();
            UpravRozvrzeni();
            SpustDotaz();
        };
    }

    // prizpusobi sirku a vysku ovladacu pri zmene velikosti okna
    private void UpravRozvrzeni()
    {
        if (dgvResult.Parent is not Panel p) return;
        int sirka = p.ClientSize.Width  - p.Padding.Horizontal;
        int vyska = p.ClientSize.Height - p.Padding.Vertical;
        txtSQL.Width     = sirka;
        dgvResult.Width  = sirka;
        dgvResult.Height = Math.Max(vyska - dgvResult.Top, 50);
    }

    // rozdeli SQL na prikazy podle stredniku, spusti kazdy zvlast
    private void SpustDotaz()
    {
        var sql = txtSQL.Text.Trim();
        if (string.IsNullOrWhiteSpace(sql)) return;

        try
        {
            var prikazy = sql.Split(';',
                StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

            DataTable? vysledek = null;
            foreach (var prikaz in prikazy)
            {
                if (prikaz.TrimStart().StartsWith("SELECT", StringComparison.OrdinalIgnoreCase))
                    vysledek = _db.ExecuteQuery(prikaz + ";");
                else
                    _db.ExecuteNonQuery(prikaz + ";");
            }

            dgvResult.DataSource = vysledek;
            ZobrazStav(vysledek != null
                ? $"OK  Radku: {vysledek.Rows.Count}"
                : "OK  Dotaz proveden.", Color.DarkGreen);

            NactiTabulky();
        }
        catch (Exception ex)
        {
            ZobrazStav("CHYBA: " + ex.Message, Color.DarkRed);
        }
    }

    private void ZobrazStav(string text, Color barva)
    {
        lblStatus.Text      = text;
        lblStatus.ForeColor = barva;
    }

    private void NactiTabulky()
    {
        lstTables.Items.Clear();
        foreach (var tbl in _db.GetTableNames())
            lstTables.Items.Add(tbl);
    }

    // vytvori nebo otevre databazi v AppData
    private void OtevriDatabazi()
    {
        _db?.Dispose();
        var slozka = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "SqlVyuka");
        Directory.CreateDirectory(slozka);
        _db = new DatabaseManager(Path.Combine(slozka, "vyuka.db"));
    }

    protected override void OnFormClosed(FormClosedEventArgs e)
    {
        base.OnFormClosed(e);
        _db?.Dispose();
    }
}
